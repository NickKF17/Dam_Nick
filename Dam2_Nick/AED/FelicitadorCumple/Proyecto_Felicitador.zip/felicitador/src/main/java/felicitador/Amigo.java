package felicitador;

import java.time.LocalDate;

/**
 * Guarda los datos de un amigo.
 */
public class Amigo {

    private final String apellido;
    private final String nombre;
    private final LocalDate fechaNacimiento;
    private final String email;

    public Amigo(String apellido, String nombre, LocalDate fechaNacimiento, String email) {
        this.apellido = apellido;
        this.nombre = nombre;
        this.fechaNacimiento = fechaNacimiento;
        this.email = email;
    }

    public String getApellido() {
        return apellido;
    }

    public String getNombre() {
        return nombre;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public String getEmail() {
        return email;
    }
}
