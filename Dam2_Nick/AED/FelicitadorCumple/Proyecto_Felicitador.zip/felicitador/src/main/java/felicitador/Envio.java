package felicitador;

/**
 * Interfaz: dice QUÉ tiene que saber hacer cualquier método de envío.
 *
 * Hoy tenemos EnvioConsola y EnvioEmail. Si mañana queremos enviar SMS,
 * creamos EnvioSMS implementando esta interfaz y el resto no cambia.
 */
public interface Envio {

    void enviar(String destino, String asunto, String texto);
}
