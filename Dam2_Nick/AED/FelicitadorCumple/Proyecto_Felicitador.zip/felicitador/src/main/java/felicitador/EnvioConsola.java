package felicitador;

/**
 * Solo escribe el mensaje por pantalla. Es útil para probar sin mandar nada.
 */
public class EnvioConsola implements Envio {

    @Override
    public void enviar(String destino, String asunto, String texto) {
        System.out.println("--- Mensaje para " + destino + " ---");
        System.out.println("Asunto: " + asunto);
        System.out.println(texto);
        System.out.println();
    }
}
