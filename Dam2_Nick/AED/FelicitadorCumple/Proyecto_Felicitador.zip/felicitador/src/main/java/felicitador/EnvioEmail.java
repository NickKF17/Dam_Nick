package felicitador;

import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

import java.util.Properties;

/**
 * Envía correos electrónicos de verdad usando la librería Jakarta Mail (angus-mail).
 */
public class EnvioEmail implements Envio {

    private final String usuario;
    private final String password;
    private final Properties propiedades = new Properties();

    public EnvioEmail(String servidor, int puerto, String usuario, String password) {
        this.usuario = usuario;
        this.password = password;

        propiedades.put("mail.smtp.host", servidor);
        propiedades.put("mail.smtp.port", String.valueOf(puerto));
        propiedades.put("mail.smtp.auth", "true");
        propiedades.put("mail.smtp.starttls.enable", "true");
    }

    @Override
    public void enviar(String destino, String asunto, String texto) {
        Session sesion = Session.getInstance(propiedades, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(usuario, password);
            }
        });

        try {
            MimeMessage mensaje = new MimeMessage(sesion);
            mensaje.setFrom(new InternetAddress(usuario));
            mensaje.setRecipient(Message.RecipientType.TO, new InternetAddress(destino));
            mensaje.setSubject(asunto, "UTF-8");
            mensaje.setText(texto, "UTF-8");
            Transport.send(mensaje);
        } catch (MessagingException e) {
            throw new RuntimeException("No se pudo enviar el correo a " + destino, e);
        }
    }
}
