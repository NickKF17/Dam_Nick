package felicitador;

import java.io.IOException;
import java.time.LocalDate;
import java.time.Year;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase principal de la lógica. No sabe si los datos vienen de un archivo o de
 * una base de datos, ni si enviamos email o SMS: solo usa las dos interfaces
 * (FuenteDatos y Envio) que le pasamos al crearla.
 */
public class Felicitador {

    private final FuenteDatos fuenteDatos;
    private final Envio envio;

    public Felicitador(FuenteDatos fuenteDatos, Envio envio) {
        this.fuenteDatos = fuenteDatos;
        this.envio = envio;
    }

    /**
     * Dice si hoy es el cumpleaños de alguien.
     *
     * Caso especial: quien nació el 29 de febrero celebra el 28 de febrero
     * en los años que no son bisiestos.
     */
    public static boolean cumpleHoy(LocalDate fechaNacimiento, LocalDate hoy) {
        boolean nacioEl29Febrero = fechaNacimiento.getMonthValue() == 2
                && fechaNacimiento.getDayOfMonth() == 29;

        if (nacioEl29Febrero && !Year.isLeap(hoy.getYear())) {
            return hoy.getMonthValue() == 2 && hoy.getDayOfMonth() == 28;
        }

        return fechaNacimiento.getMonthValue() == hoy.getMonthValue()
                && fechaNacimiento.getDayOfMonth() == hoy.getDayOfMonth();
    }

    /**
     * Felicita a los que cumplen años en la fecha indicada y avisa al resto.
     * Devuelve la lista de cumpleañeros.
     */
    public List<Amigo> felicitar(LocalDate hoy) throws IOException {
        List<Amigo> amigos = fuenteDatos.leerAmigos();

        // 1) Buscamos quién cumple años hoy
        List<Amigo> cumpleaneros = new ArrayList<>();
        for (Amigo amigo : amigos) {
            if (cumpleHoy(amigo.getFechaNacimiento(), hoy)) {
                cumpleaneros.add(amigo);
            }
        }

        for (Amigo cumpleanero : cumpleaneros) {
            // 2) Mensaje de felicitación
            envio.enviar(
                    cumpleanero.getEmail(),
                    "¡Feliz cumpleaños!",
                    "¡Feliz cumpleaños, querido/a " + cumpleanero.getNombre() + "!");

            // 3) Recordatorio para todos los demás
            for (Amigo otro : amigos) {
                if (otro == cumpleanero) {
                    continue;
                }
                String texto = "Querido/a " + otro.getNombre() + ",\n\n"
                        + "Hoy es el cumpleaños de " + cumpleanero.getNombre()
                        + " " + cumpleanero.getApellido() + ".\n"
                        + "¡No olvides enviarle un mensaje!";
                envio.enviar(otro.getEmail(), "Recordatorio de cumpleaños", texto);
            }
        }

        return cumpleaneros;
    }
}
