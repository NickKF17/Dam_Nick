package felicitador;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Lee los amigos desde un archivo de texto plano con este formato:
 *
 * last_name, first_name, date_of_birth, email
 * Doe, John, 1982/10/08, john.doe@foobar.com
 */
public class FuenteArchivo implements FuenteDatos {

    // Las fechas vienen escritas como 1982/10/08
    private static final DateTimeFormatter FORMATO = DateTimeFormatter.ofPattern("yyyy/MM/dd");

    private final Path ruta;

    public FuenteArchivo(Path ruta) {
        this.ruta = ruta;
    }

    @Override
    public List<Amigo> leerAmigos() throws IOException {
        List<Amigo> amigos = new ArrayList<>();
        List<String> lineas = Files.readAllLines(ruta, StandardCharsets.UTF_8);

        // Empezamos en 1 para saltar la primera línea (la cabecera)
        for (int i = 1; i < lineas.size(); i++) {
            String linea = lineas.get(i).trim();
            if (linea.isEmpty()) {
                continue; // saltamos líneas vacías
            }

            String[] partes = linea.split(",");
            String apellido = partes[0].trim();
            String nombre = partes[1].trim();
            LocalDate fecha = LocalDate.parse(partes[2].trim(), FORMATO);
            String email = partes[3].trim();

            amigos.add(new Amigo(apellido, nombre, fecha, email));
        }

        return amigos;
    }
}
