package felicitador;

import java.io.IOException;
import java.util.List;

/**
 * Interfaz: dice QUÉ tiene que saber hacer una fuente de datos,
 * pero no CÓMO lo hace.
 *
 * Hoy leemos de un archivo (FuenteArchivo). Si mañana queremos usar SQLite,
 * creamos una clase FuenteSQLite que implemente esta interfaz y no hay que
 * cambiar nada más del programa.
 */
public interface FuenteDatos {

    List<Amigo> leerAmigos() throws IOException;
}
