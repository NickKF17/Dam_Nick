package felicitador;

import java.io.IOException;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Punto de entrada del programa.
 *
 *   (sin argumentos)         -> escribe los mensajes en pantalla (modo prueba)
 *   --email                  -> envía correos de verdad (hay que definir variables de entorno)
 *   --fecha 2026/10/08       -> simula que hoy es esa fecha
 */
public class Main {

    public static void main(String[] args) throws IOException {
        List<String> argumentos = List.of(args);

        FuenteDatos fuente = new FuenteArchivo(Path.of("amigos.txt"));

        Envio envio;
        if (argumentos.contains("--email")) {
            // Los datos secretos se leen de variables de entorno, no se escriben en el código
            String servidor = System.getenv().getOrDefault("SMTP_SERVIDOR", "smtp.gmail.com");
            int puerto = Integer.parseInt(System.getenv().getOrDefault("SMTP_PUERTO", "587"));
            String usuario = System.getenv("SMTP_USUARIO");
            String password = System.getenv("SMTP_PASSWORD");
            if (usuario == null || password == null) {
                System.out.println("Faltan las variables de entorno SMTP_USUARIO y SMTP_PASSWORD.");
                return;
            }
            envio = new EnvioEmail(servidor, puerto, usuario, password);
        } else {
            envio = new EnvioConsola();
        }

        LocalDate hoy = LocalDate.now();
        int posicion = argumentos.indexOf("--fecha");
        if (posicion >= 0) {
            hoy = LocalDate.parse(argumentos.get(posicion + 1), DateTimeFormatter.ofPattern("yyyy/MM/dd"));
        }

        Felicitador felicitador = new Felicitador(fuente, envio);
        List<Amigo> cumpleaneros = felicitador.felicitar(hoy);

        if (cumpleaneros.isEmpty()) {
            System.out.println("Hoy no cumple años ningún amigo.");
        }
    }
}
