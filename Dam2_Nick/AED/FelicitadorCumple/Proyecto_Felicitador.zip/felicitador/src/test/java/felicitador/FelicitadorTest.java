package felicitador;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Tests de la lógica principal.
 *
 * Usamos Mockito para crear objetos simulados (mocks) de FuenteDatos y Envio:
 *  - FuenteDatos falsa: devuelve amigos fijos, sin leer ningún archivo.
 *  - Envio falso: no manda nada, solo apunta las llamadas para poder comprobarlas.
 */
class FelicitadorTest {

    private FuenteDatos fuente;
    private Envio envio;
    private List<Amigo> amigos;

    @BeforeEach
    void preparar() throws IOException {
        fuente = mock(FuenteDatos.class);
        envio = mock(Envio.class);

        amigos = new ArrayList<>();
        amigos.add(new Amigo("Doe", "John", LocalDate.of(1982, 10, 8), "john.doe@foobar.com"));
        amigos.add(new Amigo("Ann", "Mary", LocalDate.of(1975, 9, 11), "mary.ann@foobar.com"));
        amigos.add(new Amigo("Lopez", "Carlos", LocalDate.of(2000, 2, 29), "carlos.lopez@foobar.com"));

        when(fuente.leerAmigos()).thenReturn(amigos);
    }

    // ---------- cumpleHoy (pruebas unitarias, sin mocks) ----------

    @Test
    void cumpleNormal() {
        assertTrue(Felicitador.cumpleHoy(LocalDate.of(1982, 10, 8), LocalDate.of(2026, 10, 8)));
    }

    @Test
    void noEsSuDia() {
        assertFalse(Felicitador.cumpleHoy(LocalDate.of(1982, 10, 8), LocalDate.of(2026, 10, 9)));
    }

    @Test
    void nacido29FebreroEnAnioBisiesto() {
        assertTrue(Felicitador.cumpleHoy(LocalDate.of(2000, 2, 29), LocalDate.of(2028, 2, 29)));
    }

    @Test
    void nacido29FebreroEnAnioNoBisiestoSeFelicitaElDia28() {
        assertTrue(Felicitador.cumpleHoy(LocalDate.of(2000, 2, 29), LocalDate.of(2027, 2, 28)));
    }

    @Test
    void nacido29FebreroEnAnioBisiestoNoSeFelicitaElDia28() {
        assertFalse(Felicitador.cumpleHoy(LocalDate.of(2000, 2, 29), LocalDate.of(2028, 2, 28)));
    }

    @Test
    void nacido28FebreroNormalEnAnioNoBisiesto() {
        assertTrue(Felicitador.cumpleHoy(LocalDate.of(1990, 2, 28), LocalDate.of(2027, 2, 28)));
    }

    // ---------- felicitar (con mocks) ----------

    @Test
    void felicitaAlCumpleanero() throws IOException {
        new Felicitador(fuente, envio).felicitar(LocalDate.of(2026, 10, 8));

        verify(envio).enviar(
                "john.doe@foobar.com",
                "¡Feliz cumpleaños!",
                "¡Feliz cumpleaños, querido/a John!");
    }

    @Test
    void enviaRecordatorioALosDemas() throws IOException {
        new Felicitador(fuente, envio).felicitar(LocalDate.of(2026, 10, 8));

        String texto = "Querido/a Mary,\n\n"
                + "Hoy es el cumpleaños de John Doe.\n"
                + "¡No olvides enviarle un mensaje!";
        verify(envio).enviar("mary.ann@foobar.com", "Recordatorio de cumpleaños", texto);
    }

    @Test
    void elCumpleaneroNoRecibeRecordatorio() throws IOException {
        new Felicitador(fuente, envio).felicitar(LocalDate.of(2026, 10, 8));

        verify(envio, never()).enviar(
                eq("john.doe@foobar.com"), eq("Recordatorio de cumpleaños"), any());
    }

    @Test
    void totalDeMensajes() throws IOException {
        // 1 felicitación + 2 recordatorios
        new Felicitador(fuente, envio).felicitar(LocalDate.of(2026, 10, 8));

        verify(envio, times(3)).enviar(any(), any(), any());
    }

    @Test
    void siNoHayCumpleNoSeEnviaNada() throws IOException {
        new Felicitador(fuente, envio).felicitar(LocalDate.of(2026, 1, 1));

        verify(envio, never()).enviar(any(), any(), any());
    }

    @Test
    void nacido29FebreroSeFelicitaElDia28EnAnioNoBisiesto() throws IOException {
        new Felicitador(fuente, envio).felicitar(LocalDate.of(2027, 2, 28));

        verify(envio).enviar(
                "carlos.lopez@foobar.com",
                "¡Feliz cumpleaños!",
                "¡Feliz cumpleaños, querido/a Carlos!");
    }

    @Test
    void dosCumpleanosElMismoDia() throws IOException {
        amigos.add(new Amigo("Ruiz", "Laura", LocalDate.of(1990, 10, 8), "laura.ruiz@foobar.com"));

        List<Amigo> cumpleaneros = new Felicitador(fuente, envio).felicitar(LocalDate.of(2026, 10, 8));

        assertEquals(2, cumpleaneros.size());
    }
}
