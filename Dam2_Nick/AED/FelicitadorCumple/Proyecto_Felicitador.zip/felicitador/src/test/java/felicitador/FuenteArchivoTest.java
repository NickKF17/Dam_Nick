package felicitador;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

/**
 * Prueba que el archivo de texto se lee bien.
 * Aquí NO usamos mocks: se crea un archivo temporal de verdad.
 */
class FuenteArchivoTest {

    @TempDir
    Path carpetaTemporal;

    @Test
    void leeLosAmigosDelArchivo() throws IOException {
        Path archivo = carpetaTemporal.resolve("amigos.txt");
        Files.writeString(archivo,
                "last_name, first_name, date_of_birth, email\n"
                        + "Doe, John, 1982/10/08, john.doe@foobar.com\n"
                        + "Ann, Mary, 1975/09/11, mary.ann@foobar.com\n");

        List<Amigo> amigos = new FuenteArchivo(archivo).leerAmigos();

        assertEquals(2, amigos.size());
        assertEquals("John", amigos.get(0).getNombre());
        assertEquals("Doe", amigos.get(0).getApellido());
        assertEquals(LocalDate.of(1982, 10, 8), amigos.get(0).getFechaNacimiento());
        assertEquals("mary.ann@foobar.com", amigos.get(1).getEmail());
    }

    @Test
    void ignoraLineasVacias() throws IOException {
        Path archivo = carpetaTemporal.resolve("amigos.txt");
        Files.writeString(archivo,
                "last_name, first_name, date_of_birth, email\n"
                        + "\n"
                        + "Doe, John, 1982/10/08, john.doe@foobar.com\n"
                        + "\n");

        List<Amigo> amigos = new FuenteArchivo(archivo).leerAmigos();

        assertEquals(1, amigos.size());
    }
}
